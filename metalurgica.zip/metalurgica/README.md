# ANDRÉ SERRALHEIRO

Site estatico para apresentar a serralheria, feito com HTML, CSS e JavaScript puro.

## Abrir localmente

Com o XAMPP/Apache ligado, acesse:

```text
http://localhost/metalurgica/
```

## Antes de publicar

- WhatsApp configurado: `https://wa.me/5521968587713`.
- Substituir as imagens por fotos reais dos trabalhos, quando tiver.
- Ao enviar para a Vercel, usar esta pasta como raiz do projeto.
